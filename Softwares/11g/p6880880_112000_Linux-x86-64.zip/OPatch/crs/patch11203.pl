#!/usr/local/bin/perl
#
# patch11203.pl
#
# Copyright (c) 2007, 2015, Oracle and/or its affiliates. All rights reserved.
#
#    NAME
#      patch11203.pl - Auto patching tool for Oracle Clusterware/RAC home.
#
#    DESCRIPTION
#      patch11203.pl -  Auto patching tool for Oracle Clusterware/RAC home.
#
#    MODIFIED   (MM/DD/YY)
#       phnguyen   11/18/14  - Grab Srujan's trans on 11.2.0.3.7 for bug 20037818
#       prakhsin   10/15/13  - Bug 17533086 : exit if crsctl command fails
#       prakhsin   10/03/13  - Bug 16840875 : Verify Patch storage in report
#                              mode
#       prakhsin   10/03/13  - Bug 16839983 : Exit Opatch with proper message
#       prakhsin   10/03/13  - Bug 14628998 : Check if CRS home for -och option
#       prakhsin   09/16/13  - Bug 12374866 : modify constructpatchlist sub
#                              routine
#       prakhsin   08/13/13  - Bug 12620280 : fix help cmds allignment
#       prakhsin   05/28/13  - Bug 16855484 : checkApplicable prereq fix
#       cawan      09/12/12  - Report command change for unlock/patch
#       cawan      09/06/12  - Fix Bug #14507819
#       billi      06/29/12  - Fix Bug 14162318
#       cawan      06/27/12  - Fix Bug #14239219
#       srukumar   05/09/12  - Fixing bug 14052856
#       srukumar   01/19/12  - Fix bug in getOpatchver for OPATCH_DEBUG mode
#       fisong     01/10/12  - Fixing bug 11074819
#       srukumar   11/03/11  - Stop dbconsole
#       srukumar   11/03/11  - Stop dbconsole, agent.
#       ksviswan   05/28/11  - Fix Bug 12588615
#       ksviswan   05/24/11  - Add compat option for backward compatibility
#       ksviswan   03/08/11  - opauto segregation.
#       ksviswan   03/02/11  - Fix Bugs 11807070, 11824391, 9965477
#       ksviswan   01/25/11  - Fix bug 11670519.
#       ksviswan   01/25/11  - Out of place patching support
#       ksviswan   10/01/10  - XbranchMerge ksviswan_bug-10147375 from main
#       ksviswan   09/27/10  - XbranchMerge ksviswan_opauto_copy_initfiles from
#                              main
#       ksviswan   09/22/10  - XbranchMerge ksviswan_bug-10132822 from main
#       ksviswan   09/20/10  - Fix Bugs 9475556,9869238,9869250
#       ksviswan   08/25/10  - Fix Bug 9863515,9869222,10055092,9869222
#       ksviswan   06/24/10  - Fix Bug 9849173
#       ksviswan   06/07/10  - Fix Bug 9786647
#       ksviswan   05/31/10  - Fix Bug 9755296
#       ksviswan   05/25/10  - Fix Bugs 9719845,9719790,9750704 and 9750739
#       ksviswan   04/21/10  - Support Automation for New PSU patch format.
#       ksviswan   03/06/10  - Fix Bugs 9453069 and 9437772
#       ksviswan   02/25/10  - Fix Bugs 9362121,9358228,9409808
#                              add checkCompoent logic
#       ksviswan   01/08/10  - Fix bug 9209886 and set default log dir.
#       ksviswan   05/08/09  - Implement 11.2 autopatching support 
#
#   NOTES
#
# Documentation: usage output,
#   execute this script with -h option
#
#

################ Documentation ################

# The SYNOPSIS section is printed out as usage when incorrect parameters
# are passed

=head1 NAME

  patch11203.pl - Auto patching tool for Oracle Clusterware/RAC home.

=head1 SYNOPSIS

  opatch auto <patch directory>
              [-oh  <oracle home location>]
              [-och <crs home location>]
              [-rollback]
              [-ocmrf <ocm response file location>]
              [-norestart]
	      [-report]
              [-olderver]

  Options:

   patch_directory

             Default is the current directory.
             This is the top level directory path where the patch is 
             unzipped. 
            
             Always unzip the gipsu/gi one-off in a empty directory
             where there are no other directory/files existing.  
            
             If the directory under which the patch is unzipped is /tmp/patchdir 
             
             Example:
             opatch auto /tmp/patchdir



 -rollback  

             The patch will be rolled back, not applied
             This option requires patch_directory to be passed

             Example:
             opatch auto /tmp/patchdir -rollback

 -oh         Database/Clusterware home locations    

             comma_delimited_list_of_oralcehomes_to_patch
             The default is all applicable Oracle Homes including
             the clusterware home .Use this option  to patch RDBMS homes where
             no database is registered or any specific database home or
             clusterware home. In order to patch a 11.2 Database under Grid home of 
	     version 12.1 and above, run opatch auto from the DB home.

             Example:
             opatch auto /tmp/patchdir -oh <oracle_home1_path,oracle_home2_path>

 -och        Grid infrastructure home location
             absolute path of crs home location. This is only used
             to patch Clusterware home when the clusterware stack is down
         
             Example:
             opatch auto /tmp/patchdir -och <oracle_gridhome_path>

 -ocmrf      OCM response file location

             Absolute path of the OCM response file. This is required for
	     silent mode patching

 -norestart  
	     The clusterware stack and database home resources will not be 
	     started after patching.

 -report
             opatch would be run in a report mode where all the prereq checks
	     would be performed without modifying the binaries. The patch would
	     not be applied/rolled-back on the home.

 -olderver
             This parameter must be passed when the clusterware stack is down, along 
             with the -och parameter. It must only be used if the Grid Home version is 
             11.2.0.2 or older and not for newer versions of the Grid.

             Example:
             opatch auto /tmp/patchdir -och <oracle_home> -olderver 


  To patch a shared Clusterware or Database home, 
  Refer to Section "Patching installation to RAC database and/or the GI home" in the 
  Patch Readme document and follow the steps.

                                          
=head1 DESCRIPTION


  This script automates the complete patching process for a Clusterware
  or RAC database home. This script must be run as root user and needs Opatch version
  10.2.0.3.3 or above. 
  Case 1 -  On each node of the CRS cluster in case of Non Shared CRS Home.
  Case 2 -  On any one node of the CRS cluster is case of Shared CRS home.          

=cut

################ End Documentation ################

use strict;
use English;
use Cwd;
use Cwd 'abs_path';
use FileHandle;
use File::Basename;
use File::Spec::Functions;
use File::Copy;
use Sys::Hostname;        
use Net::Ping;
use Getopt::Long;
use Pod::Usage;

BEGIN {
  # Add the directory of this file to the search path
   my $crspatchincldir = $ENV{'CRSPATCH_INCL_PATH'};
   
   if ($crspatchincldir) {
      unshift @INC, $crspatchincldir;
   }
   else
   {
      my $scriptdir = abs_path(dirname($PROGRAM_NAME));
      my $gridhome = `$scriptdir/../../srvm/admin/getcrshome`;
      my $incdir = "$gridhome/crs/install";
      
      unshift @INC, $incdir;
   }
}

use constant SUCCESS               =>  "1";
use constant FAILED                =>  "0";
use constant TRUE                  =>  "1";
use constant FALSE                 =>  "0";
use constant ERROR                 =>  "-1";

#Global variables
our $g_help = 0;
our $g_unlock = 0;
our $g_patch = 0;
our $ghome = 0;

my $scrdir = abs_path(dirname ($0));
my $incdir = "$scrdir/../../crs/install";
$ghome = `$scrdir/../../srvm/admin/getcrshome`;

# pull all parameters defined in crsconfig_params and s_crsconfig_defs (if
# it exists) as variables in Perl
my $paramfile_default = catfile ($ghome, "crs", "install", "crsconfig_params");

# pull all definitions in s_crsconfig_defs (if it exists) as variables in Perl
# this file might not exist for all platforms
my $defsfile = catfile ($ghome, "crs", "install",  "s_crsconfig_defs");
my $timestamp = gentimeStamp();

my $deflogdir = dirname(dirname($scrdir)) . "/cfgtoollogs";
my $logfile;
my $report_file;
my $config_file;
my $customLogDir;
my $step_count = 1;

if (-e $deflogdir)
{
   $logfile     = catfile($deflogdir,  "opatchauto$timestamp.log");
   $report_file = catfile($deflogdir,  "opatchauto$timestamp.report.log");
   $config_file = catfile($deflogdir,  "opatchauto$timestamp.cfg.log");

   $customLogDir= $deflogdir . "/opatchauto/core";
}
else
{
   $logfile     = catfile ($scrdir, "log", "opatchauto$timestamp.log");
   $report_file = catfile ($scrdir, "log", "opatchauto$timestamp.report.log");
   $config_file = catfile ($scrdir, "log", "opatchauto$timestamp.cfg.log");

   $customLogDir= $scrdir . "/log";
}

print "\nThis is the main log file: $logfile\n";
print "\nThis file will show your detected configuration and all the steps that opatchauto attempted to do on your system:\n$report_file\n\n";


my $PARAM_FILE_PATH = $paramfile_default;
my $patchdir;
my $patchdbdir;
my $patchfile;
my $patchnum;
my $rollback;
my $ohome;
my $chome;
my $ocmrf;
my $report;
my $norestart;
my $pwd = $ENV{'PWD'}?$ENV{'PWD'}:getcwd();
my $OS = `uname`;
chomp $OS;
my $ORA_CRS_HOME;
my $ORA_CRS_USER;
my $patchType;
my $homeType;
my @dbhomes = ();
my @homestopatch = ();
my @homestostart = ();
my ($name, $passwd, $uid, $gid, $quota, $comment, $gcos, $dir, $shell) = getpwuid( $< );
my $crs_running;
my @gipatches = ();
my @hapatches = ();
my @dbpatches = ();
my @gipatchIds = ();
my @hapatchIds = ();
my @dbpatchIds = ();
my @patchIds = ();
my @patchLocs = ();
my $isconflictok;
my $op_silent;
my $sihainst = 0;
my $cfg;
my $dest_crshome;
my $prereq_status = SUCCESS;

#TBR
my $overbose;

my $unzip;
my $rsh;
my $ssh;
my $su;
my $sed;
my $echo;
my $mkdir;
my $cat;
my $rcp;
my $kill;
my $fuser;
my $olrloc;
my $ocrloc;

if ( $OS eq "Linux")
{
$unzip = "/usr/bin/unzip";
$rsh = "/usr/bin/rsh";
$ssh = "/usr/bin/ssh";
$su = "/bin/su";
$sed = "/bin/sed";
$echo = "/bin/echo";
$mkdir = "/bin/mkdir";
$cat = "/bin/cat";
$rcp = "/usr/bin/rcp";
$kill = "/bin/kill";
$fuser = "/sbin/fuser";
$olrloc = "/etc/oracle/olr.loc";
$ocrloc = "/etc/oracle/ocr.loc";
}
elsif ($OS eq "HP-UX")
{
$unzip = "/usr/local/bin/unzip";
$rsh = "/usr/bin/remsh";
$ssh = "/usr/bin/ssh";
$su =  "/usr/bin/su";
$sed = "/usr/bin/sed";
$echo = "/usr/bin/echo";
$mkdir = "/usr/bin/mkdir";
$cat = "/usr/bin/cat";
$rcp = "/usr/bin/rcp";
$kill = "/usr/bin/kill";
$fuser = "/usr/sbin/fuser";
$olrloc = "/var/opt/oracle/olr.loc";
$ocrloc = "/var/opt/oracle/ocr.loc";
}
elsif ($OS eq "AIX" )
{
$unzip = "/usr/local/bin/unzip";
$rsh = "/usr/bin/rsh";
$ssh = "/usr/bin/ssh";
$su =  "/usr/bin/su";
$sed = "/usr/bin/sed";
$echo = "/usr/bin/echo";
$mkdir = "/usr/bin/mkdir";
$cat = "/usr/bin/cat";
$rcp = "/usr/bin/rcp";
$kill = "/usr/bin/kill";
$fuser = "/usr/sbin/fuser";
$olrloc = "/etc/oracle/olr.loc";
$ocrloc = "/etc/oracle/ocr.loc";
}
elsif ( $OS eq "SunOS" )
{
$unzip = "/usr/bin/unzip";
$rsh = "/usr/bin/rsh";
$ssh = "/usr/local/bin/ssh";
$su =  "/usr/bin/su";
$sed = "/usr/bin/sed";
$echo = "/usr/bin/echo";
$mkdir = "/usr/bin/mkdir";
$cat = "/usr/bin/cat";
$rcp = "/usr/bin/rcp";
$kill = "/usr/bin/kill";
$fuser = "/usr/sbin/fuser";
$olrloc = "/var/opt/oracle/olr.loc";
$ocrloc = "/var/opt/oracle/ocr.loc";
}
else
{
  die "ERROR: $OS is an Unknown Operating System\n";
}

# the return code to give when the incorrect parameters are passed
my $usage_rc = 1;

GetOptions('patchdir=s'     => \$patchdir,
           'patchfile=s'    => \$patchfile,
           'patchnum=s'     => \$patchnum,
           'paramfile=s'    => \$PARAM_FILE_PATH,
           'rollback'       => \$rollback,
           'oh=s'           => \$ohome,
           'och=s'          => \$chome,
           'ocmrf=s'        => \$ocmrf,
	   'report'         => \$report,
	   'config=s'       => \$config_file,
           'norestart'      => \$norestart,
           'unlock!'        => \$g_unlock,
           'patch!'         => \$g_patch,
           'desthome=s'     => \$dest_crshome,
           'help!'          => \$g_help) or pod2usage($usage_rc);


# Check validity of args
pod2usage(-msg => "Invalid extra options passed: @ARGV",
          -exitval => $usage_rc) if (@ARGV);

if ($g_unlock && $dest_crshome) {
   $PARAM_FILE_PATH = catfile ($dest_crshome, 'crs', 'install', "crsconfig_params");
} elsif ($g_patch && $dest_crshome) {
   $PARAM_FILE_PATH = catfile ($dest_crshome, 'crs', 'install', "crsconfig_params");
}

### Set this host name (lower case and no domain name)
our $HOST = tolower_host();
die "$!" if ($HOST eq "");

# Set the following vars appropriately for cluster env
### check if run as super user
our $SUPERUSER = check_SuperUser ();
if (!$SUPERUSER) {
  exitOpatch("Insufficient privileges to execute this script\n");
}

$patchdir = "$patchdir/$patchnum";

#setupINC();

#include GI config module.
use crspatch;

if (!$g_help && ! $patchdir)
{
   error("-patchdir is a  Mandatory option");
   pod2usage(1);
}


if (checkSIHA()) {
   $sihainst = 1;
   trace("Starting Oracle Restart Patch Setup");
   crsconfig_lib->new(IS_SIHA             => $sihainst,
                     paramfile           => $PARAM_FILE_PATH,
                     osdfile             => $defsfile,
                     crscfg_trace        => TRUE,
                     crscfg_trace_file   => $logfile,
                     HOST                => $HOST
                     );
} else {
   patchcrssetup($PARAM_FILE_PATH, $defsfile, $logfile, $HOST, $SUPERUSER);
}

if ($g_unlock && $dest_crshome) { unlockPatchHome($dest_crshome); exit 0 }
elsif  ($g_patch && $dest_crshome)  { CRSPatchhome($dest_crshome); exit 0 }

trace ("INC is @INC \n");

#Subroutines used by this tool


#Remove trailing white spaces in a string
sub trim($)
{
    my $string = shift;
    $string =~ s/^\s+//;
    $string =~ s/\s+$//;
    return $string;
}


sub parseOptions
{
   if    ($g_help)   { pod2usage(0); }

   if ( ! $patchdir )
   {
      $patchdir = $pwd;
      trace("using current directory $patchdir for patch directory");
   }

   if( ! $patchfile )
   {
      trace("No -patchfile specified, assuming the patch is already uncompressed" );
   }
 
   if ($ohome && $chome)
   {
      error("Can't specify -oh with -och");
      pod2usage(1);
   }
}

sub makeCustomLogDir
{
   my $cmd;
   my $status;
   my @output;
   my $reference_dir;
   my $owner;

   #Create the CustomLogDir for opatch-core
   if( $customLogDir && ! -d $customLogDir )
   {
       if (-e $deflogdir)
       {
         $reference_dir = $deflogdir;
       }
       else
       {
          $reference_dir = $scrdir;
       }

       my $uid = (stat $reference_dir) [4];
       $owner  = (getpwuid $uid) [0];

       if ( ! $owner)
       {
         trace( "Owner set to default value");
         $owner = $ORA_CRS_USER;
       }

       # Create 'opatch' inside customLogDir with perm 755 so that all owners can access
       my $opatch_log_dir = $customLogDir . "/opatch";
       $cmd = "$mkdir -m 777 -p $opatch_log_dir";
       trace( "Executing $cmd as $owner" );
       $status = run_as_user2($owner, \@output, $cmd );
       trace( "Status: $status");

   }

   if ( ! -d $customLogDir )
   {
       trace( "Failed to create customLogDir :\n @output");
   }

}

sub createPatchdir
{
   my $cmd;
   my $status;

   #Create the patch directory
   if( $patchdir && ! -d $patchdir )
   {
       $cmd = "$mkdir -p $patchdir";
       trace( "Executing $cmd as $ORA_CRS_USER" );
       $status = run_as_user($ORA_CRS_USER, $cmd );
   }

}

sub unzipPatch
{
   my $rpatchfile = "";
   my $cmd = "";
   my $node;
   my $ask_skip;
   my @ocp_nodes_topatch;
   my $olocal;
   my $host;
   my $status;
   my @output;

   my $patchfile = $ENV{'PATCH_ZIP_FILE'};

   if ( -e $patchfile )
   {
      $cmd = "$unzip -o $patchfile -d $patchdir";
      trace( "Executing $cmd as $ORA_CRS_USER" );
      $status = run_as_user2($ORA_CRS_USER, \@output, $cmd );
      trace("unzip output is @output");
   }
}

sub findPatchType
{
  #Determine the type of patch
  my $pdir = $_[0];
  my $patchtype;
  my @cmdout;
  my @output;
  my @outp;
  my $rc;
  my $patchcount;
  my $opatch = catfile ($ORA_CRS_HOME, "OPatch", "opatch");
  my $cmd = "$opatch query -get_patch_type $pdir -oh $ORA_CRS_HOME";
  $rc = run_as_user2($ORA_CRS_USER, \@cmdout, $cmd );
  @output = grep(/This patch/, @cmdout);
  trace("output is @output");
  @outp = split(" ", $output[0]);
  $patchtype = $outp[4];
  trace ("Patch type is $patchtype");
  return $patchtype;
}

sub getpatches
{
  my @patches = ();
  my $patchcount;
  my $patchids;
  my $usrinput;

  my $bfile = catfile($patchdir, "bundle.xml");
  if (-e $bfile) {
     @patches = getpids($patchdir);
  } else {
    	  print "Enter 'yes' if you have unzipped this patch to an empty directory to proceed  (yes/no):";
          $usrinput = <STDIN>;
          if ($usrinput =~ m/yes/i) {
            ($patchcount, $patchids) = getPatchids($patchdir);
            @patches = split(/\,/, $patchids);
          } else {
              exitOpatch("Unable to find patches");
          }
  }
  trace("The patch ids are @patches");
  return @patches
}

sub constructpatchlist
{
  my $patch;
  my $ptype;

  @patchIds = getpatches();
  @patchLocs = getpatchlocs($patchdir);

  my $patchtype = "DB";
  foreach $patch (@patchIds)
  {
     $ptype = findPatchType("$patchdir/$patch");
     if ($ptype =~ m/bundle_top/) {
        $patchtype = $ptype;
     }
  }
  $patchType = $patchtype;
}


sub checkApplicable
{
   my $home = shift;
   my $ohown = getoracleowner($home);
   my $homeType = findHomeType($home);
   my $patchlist = shift;
   my $rc;
   my @cmdout;
   my @output;
   my $cmd;
   my $opatch = catfile ($home, "OPatch", "opatch");
   my $pdir; 
   my $status = FAILED;
 

   #Check if the patch is applicable
   foreach $pdir (@$patchlist)
   {
      
      
      $cmd = "$opatch prereq CheckApplicable -ph $pdir -oh $home";
      report_cmd("$cmd");
      if ( (! $report) || ($homeType eq "DB") )
      {
         $rc = run_as_user2($ohown, \@output, $cmd);
 
         @cmdout = grep(/passed/, @output);

         if ((scalar(@cmdout) > 0) && ($rc == 0)) {
            $status = SUCCESS;
         }  
	 else {
                error("Error : The opatch Applicable check failed.  The patch $pdir is not applicable to $home");
                $prereq_status = FAILED;
         }
      }
      else {
         $status = SUCCESS;
      }	 
   }
   return $status;
}

sub checkConflict
{
   my $home = shift;
   my $ohown = getoracleowner($home);
   my $patchlist = shift;
   my $rc;
   my @cmdout;
   my @output;
   my $cmd;
   my $opatch = catfile ($home, "OPatch", "opatch");
   my $pdir;
   my $status = SUCCESS;

   foreach $pdir (@$patchlist)
   {
      #Check if there are patch conflicts.
      $cmd = "$opatch prereq CheckConflictAgainstOH -ph $pdir -oh $home";
	  report_cmd("$cmd");
   
      $rc = run_as_user2($ohown, \@output, $cmd);

      @cmdout = grep(/ZOP-40/, @output);

      # if scalar(@cmdout) > 0, we found the msg we were looking for
      if ((scalar(@cmdout) > 0) && ($rc == 0)) {
         $status = FAILED;
         if (! $rollback) {
         error("The opatch Conflict check failed  for $home. The patch $pdir is either already applied or conflicting with another patch applied in the home");
         trace("The error ouput from opatch is @output");
         }
      } 
   }
   return $status;
}

sub checkComponent
{
   my $home = shift;
   my $ohown = getoracleowner($home);
   my $patchlist = shift;
   my $rc;
   my @cmdout;
   my @output;
   my $cmd;
   my $opatch = catfile ($home, "OPatch", "opatch");
   my $pdir;
   my $status = SUCCESS;
   
   foreach $pdir (@$patchlist)
   {
      #Check if the patch is applicable
      $cmd = "$opatch prereq CheckComponents -ph $pdir -oh $home";
	  report_cmd("$cmd");

      $rc = run_as_user2($ohown, \@output, $cmd);

      @cmdout = grep(/passed/, @output);

      if (!(scalar(@cmdout) >  0) || ( 0 != $rc )) {
         $status = FAILED;
         error("The opatch Component check failed. This patch is not applicable for $home");
         trace("The component check failed with following error");
         trace("@output");
      }
   }
   return $status;
}


sub applyPatch
{
   my $home = shift;
   my $ohown = getoracleowner($home);
   my $patchlist = shift;
   my $cmd = "";
   my $status;
   my $opatch = catfile ($home, "OPatch", "opatch");
   my $pdir;
   my @output = ();
   if  ($OS eq "AIX" ) {
         unloadAIXfiles();
       }
   foreach $pdir (@$patchlist)
   {
      $cmd = "$opatch napply $pdir -local $op_silent -oh $home -invPtrLoc $home/oraInst.loc";      
	  report_cmd("$cmd");
	  if ($report)
	  {
	     $cmd = "$cmd -report";
	  }
	  trace("Executing command $cmd as $ohown");
      $status = run_as_user2($ohown, \@output, $cmd );
      trace("status of apply patch " . ($report?"(report mode) ":"") . "is $status");
      trace("The apply patch " . ($report?"(report mode) ":"") . "output is @output");
      if (0 != $status) {
        error("patch $pdir  apply " . ($report?"(report mode) ":"") . "failed  for home  $home");
        last;
      } else {
        trace("patch $pdir  apply " . ($report?"(report mode) ":"") . "successful for home  $home");
        print "patch $pdir  apply " . ($report?"(report mode) ":"") . "successful for home  $home \n";
      }

   }

}

sub rollbackPatch
{
   my $home = shift;
   my $ohown = getoracleowner($home);
   my $patchlist = shift;
   my $status = 0;
   my @output = ();
   my $opatch = catfile ($home, "OPatch", "opatch");
   my $pnum;
   my $skip;

   if  ($OS eq "AIX" ) {
         unloadAIXfiles();
       }
   foreach $pnum (@$patchlist)
   {
      $skip = FALSE;
      trace("checking if patch $pnum exists in $home");
      if (checkRollback($pnum, $home)) 
      {
         my $cmd = "$opatch rollback -id $pnum -local -silent -oh $home -invPtrLoc $home/oraInst.loc";
         report_cmd("$cmd");
	 if ($report)
	 {
	    $cmd = "$cmd -report";
	 }
	 trace("Executing command $cmd as $ohown");
         $status = run_as_user2($ohown, \@output, $cmd );
         trace("status of rollback patch " . ($report?"(report mode) ":"") . "is $status");
         trace("The rollback patch " . ($report?"(report mode) ":"") . "output is @output");
      } else {
         trace("Rollback of $pnum failed. Patch may not have been applied, skipping rollback.");
         $skip = TRUE;
      }
      if (0 != $status) {
        error("patch $pnum  rollback " . ($report?"(report mode) ":"") . "failed for home  $home");
        last;
      } else {
          if (! $skip) {
             trace("patch $pnum  rollback " . ($report?"(report mode) ":"") . "successful for home $home");
             print "patch $pnum  rollback " . ($report?"(report mode) ":"") . "successful for home $home\n";
         }
      }

   }
}


sub setrdbmsfileperms
{
  my $home = $_[0];
  my $cmd ;
  my @out;
  my $rc;

  $cmd = "$home/rdbms/install/rootadd_rdbms.sh";
  report_cmd("$cmd : run as root");
  if (! $report)
  {
     @out = system_cmd_capture("$cmd");
     $rc = shift @out;

     if (0 == $rc) {
        trace("setrdbmsfileperms succeeded");
     } else {
         error("setrdbmsfileperms failed. output is @out");
     }
   }
}

sub removeproc
{
  my $home = $_[0];
  my $proc = $_[1];
  my $cmd ;
  my @out;
  my $rc;  

  my $fpath = catfile($home, "bin", $proc);
  $cmd = "$fuser -k $fpath";
  report_cmd("$cmd : run as root");
  
  if (! $report)
  {
	  trace("Invoking removeproc to clean oracle client procs");
	  @out = system_cmd_capture("$cmd");
	  $rc = shift @out;

	  if (0 == $rc) {
		 trace("fuser command success. output for $fpath is @out");
	  } else {
		 trace("fuser command output for $fpath is @out");
	  }
  }
}

sub Stopdbhome
{
   my $home = $_[0];
   my $sihadb = $_[1];
   my $ohown = $_[2];
   my $srvctlbin    = catfile ($home, "bin", "srvctl");
   my $nodename = $HOST;
   my $success = SUCCESS;
   my $cmd;
   my @output;
   my $status;
   
   my $stfile = catfile ($home, "srvm", "admin", "stophome.txt");
   $ENV{ORACLE_HOME} = $home;
   
   #Bug 10226636
   if (-e $stfile) {
      unlink $stfile;
   }

   if ( ! $sihadb) {
      $cmd = "$srvctlbin stop home -o $home -s $stfile -n $nodename -f";
   } else {
      $cmd = "$srvctlbin stop home -o $home -s $stfile -f";
   }

   $status = run_as_user2($ohown, \@output, $cmd );

   trace("$cmd output is @output");

   if ($status != 0) {
     error("Failed to stop resources from  database home $home");
     $success = FAILED;
   } else {
     trace("Stopped resources from database home $home");
  }
  return $success;
}

sub PerformDBPatch
{
  my $home = shift;
  my $patchlist = shift;
  my $ohown = getoracleowner($home);
  my $cmd;
  my $status;
  my @output = ();
  my $pdir;
 
  my @crs_version = getcrsversion();


  my $issiha = isSIHA();
  if ($issiha)
  {  
     report_cmd("$home/bin/srvctl stop home -o $home -s $home/srvm/admin/stophome.txt -f"); 
  }
  else
  {
     report_cmd("$home/bin/srvctl stop home -o $home -s $home/srvm/admin/stophome.txt -n $HOST -f"); 
  }
  if ( ! $report)
  {
          print "\nStopping RAC $home ...\n";
	  if (Stopdbhome($home, $issiha, $ohown)) 
          {
		 if ($crs_version[0] == 11 && $crs_version[1] == 2 && $crs_version[2] == 0 && $crs_version[3] == 3) {
			#Bug 10131381
			removeproc($home, "oracle");
		 }
                 print "Stopped RAC $home successfully\n\n";
	  }
          else
          {
              exitOpatch("Refer log file for more details.\n");
          }
  }
  foreach $pdir (@$patchlist)
  {
     if (-e "$pdir/custom/scripts/prepatch.sh") {
        $cmd = "$pdir/custom/scripts/prepatch.sh -dbhome $home";
		report_cmd("$cmd");
     } else {
        $cmd = "true";
     }
	 	 
     if ( ! $report)
     {
        $status = run_as_user2 ($ohown, \@output, $cmd);
     }
  }
  if ($report || $status == 0) {
     if (! $report) { trace ("prepatch execution for DB home ... success"); }
     if ( $rollback ) {
       rollbackPatch($home, \@dbpatchIds);
     } else {
       applyPatch($home, \@$patchlist);
     }
   } else {
      exitOpatch("prepatch execution for DB home ... failed");
   }
  
  foreach $pdir (@$patchlist)
  {
     if (-e "$pdir/custom/scripts/postpatch.sh") {
        $cmd = "$pdir/custom/scripts/postpatch.sh -dbhome $home";
		report_cmd("$cmd");
     } else {
        $cmd = "true";
     }
	 
     if ( ! $report)
     {
        $status = run_as_user2 ($ohown, \@output, $cmd);
     }
  }

  if ( $status == 0) {
      trace ("postpatch execution for DB home ... success");
   } elsif ( ! $report) {
      exitOpatch("postpatch execution for DB home ... failed");
  }
}

sub gentimeStamp
{
  my ($sec, $min, $hour, $day, $month, $year) =
        (localtime) [0, 1, 2, 3, 4, 5];
  $month = $month + 1;
  $year = $year + 1900;

  my $ts = sprintf("%04d-%02d-%02d_%02d-%02d-%02d",$year, $month, $day, $hour, $min, $sec);
  return $ts;
}

sub getPatchids
{
 my $searchdir = $_[0];
 my $ids;
 my $line;
 my $idx;

 my @dbids = <$searchdir/*>;
 foreach $line (@dbids)
 {
  chomp($line);
  if ( -d $line) {
   $idx++;
   my @temp = split(/\//, $line);
   $ids = $ids . $temp[-1] . ",";
  }
 }
 chop $ids;
 return ($idx, $ids);
}

sub getpids
{
 my $searchdir = $_[0];
 my $bfile = catfile($searchdir, "bundle.xml");
 my @list;
 my @out;
 my $ids;
 my $tag;
 my @pids;

 @list = read_file( $bfile);

 @out = grep(/entity location/, @list);
 foreach my $rec (@out) {
   chomp($rec);
   if ($rec =~ m/custom/) {
      next;
   } else {
      $rec =~ s/<|>|"//g;
      ($tag, $ids) = split(/=/,$rec);
      push @pids, $ids;
   }
 }
 trace("The patch ids are @pids");
 return @pids;
}

sub getpatchlocs
{
 my $searchdir = $_[0];
 my $bfile = catfile($searchdir, "bundle.xml");
 my @locs = ();
 my @bfileData;
 my $tag;
 my $type;
 my @pidlist = ();
 my $ploc;
 my $pid;
 my $validtag = 0;

 if(-e $bfile)
 { 
 @bfileData = read_file($bfile);
 foreach my $entity (@bfileData) 
 {
  if($entity =~ m/<\/entity>/)
  {
    $validtag = 0;
    next;
  }
  if($entity =~ m/entity location/)
  {
   $validtag = 1;
   $entity =~ s/<|>|"//g;
   ($tag, $ploc) = split(/=/,$entity);
   chomp($ploc);
   push @locs, "$patchdir/$ploc";
   if($ploc =~ m/custom\/server/)
   {
    ($tag,$pid) = split(/server\//,$ploc);
    chomp($pid);
   }
   else
   {
    $pid = $ploc;
   }
  }
  if($entity =~ m/target type/)
  {
    $entity =~ s/<|>|"//g;
    ($tag, $type) = split(/=/,$entity);
    chomp($type);
    if(($type =~ m/crs/) && ($validtag == 1)) 
    {
      push @gipatches, "$patchdir/$ploc";
      push @gipatchIds, $pid;
    }
    elsif(($type =~ m/siha/) && ($validtag == 1)) 
    {
      push @hapatches, "$patchdir/$ploc";
      push @hapatchIds, $pid;
    }
    elsif(($type =~ m/rac/) && ($validtag == 1)) 
    {
      push @dbpatches, "$patchdir/$ploc";
      push @dbpatchIds, $pid;
    }
    else 
    {
      next;
    }
   }
  }
 }
 else
 {
   @pidlist = getpatches(); 
   foreach my $id (@pidlist)
   {
     push @locs, "$patchdir/$id";
     push @gipatches, "$patchdir/$id";
     push @hapatches, "$patchdir/$id";
     push @dbpatches, "$patchdir/$id";
     push @gipatchIds, $id;
     push @hapatchIds, $id;
     push @dbpatchIds, $id;
   }  
 } 
 trace("The GI patch locations are @gipatches");
 trace("The GI patch IDs are @gipatchIds");
 trace("The SIHA patch locations are @hapatches");
 trace("The SIHA patch IDs are @hapatchIds");
 trace("The DB patch locations are @dbpatches");
 trace("The DB patch IDs are @dbpatchIds");
 return @locs;  
} 
 
sub checkConflictforhomes
{
   my @homelist = @_;
   my $chkconflict = SUCCESS;
   my $count;

   foreach my $home (@homelist) {
     my $status;
     trace("Processing oracle home $home");
     $homeType = findHomeType($home);
     trace("Home type of $home is $homeType");
     if ($homeType eq "CRS")
     {
        if ( $rollback) {
            $status = checkComponent ($home, \@gipatches);
         } else {
            $status = (checkComponent ($home, \@gipatches) &&  checkConflict ($home, \@gipatches));
         }
     }
     elsif ($homeType eq "HA" )
     { 
        if ( $rollback) {
            $status = checkComponent ($home, \@hapatches);
         } else {
            $status = (checkComponent ($home, \@hapatches) &&  checkConflict ($home, \@hapatches));
         }
     } 
     else {
        if ( $rollback) {
             $status = checkComponent ($home, \@dbpatches);
        } else {
             $status = (checkComponent ($home, \@dbpatches) &&  checkConflict ($home, \@dbpatches));
        }
     }

     trace("Status of component/conflict check  for $home is $status");

     if ($status) {
         trace(" Conflict check passes for oracle home  $home");
     } else {
         error("Conflict check failed for oracle home  $home");
         $count++;
     }
  }

  
  if ($count == 0) {
    trace ("Conflict check passed  for all oracle homes");
  } else {
    error ("Conflict check failed");
    $chkconflict = FAILED;
  }

  return $chkconflict;
}

sub checkOCM
{
  my $silentflg;
  my $ocmrspfile;

  #check if opatch is bundled with OCM
  if ( -e "$ORA_CRS_HOME/OPatch/ocm/bin/emocmrsp")
  {
    if ($ocmrf)
    {
      $ocmrspfile = $ocmrf;
    } 
    else {
       error("OPatch  is bundled with OCM, Enter the absolute OCM response file path:") ;
       $ocmrspfile = <STDIN>;
       chomp $ocmrspfile;
       $ocmrspfile =~ s/^\s+//;
       $ocmrspfile =~ s/\s+$//;
    }
    if ( -e $ocmrspfile)
    {
      $silentflg = "-silent -ocmrf $ocmrspfile";
    }
    else
    {
      exitOpatch("Invalid response file path, To regenerate an OCM response file run $ORA_CRS_HOME/OPatch/ocm/bin/emocmrsp");
    }
  }
  else
  {
    #report( 0, 0, "$opatch is not bundled with OCM" );
    $silentflg = "-silent";
  }

  return $silentflg;

}



sub isHomesShared
{
   my @homelist = @_;
   my $path;
   my $isshared = FALSE;
   my $usrinput;

   foreach my $home (@homelist) {
      my $homeType = findHomeType($home);
      if (($homeType eq "CRS") || ($homeType eq "HA")) {
         $path = catdir( $home, 'crs', 'install');
      } else {
         $path = $home;
      }

      $isshared = ispathShared($path);
      trace("the ishared value is $isshared");
      if  ( (! $report) && ($isshared == TRUE) ) {
          if ($homeType eq "CRS")  {
             checkClusterstat();
          } else {
             checkdbhomestat($home);
          }
      } elsif ($isshared == ERROR) {
        print "\n";
        print "Unable to determine if $home is shared oracle home\n";
        print "Enter 'yes' if this is not a shared home or if the prerequiste actions are performed to patch this shared home (yes/no):";
          $usrinput = <STDIN>;
          if ($usrinput =~ m/yes/i) {
             next;
          }else {
             print "\n";
             exitOpatch("Refer to opatch auto help (opatch auto -h) for patching shared homes and follow the steps\n");
          }

      } else {
          trace("The oracle home $home is not shared");
      }
   }
}


sub getOpatchver
{
   my $home = shift;
   my $ohown = getoracleowner($home);
   my $rc;
   my @cmdout;
   my @output;
   my $cmd;
   my $opatch = catfile ($home, "OPatch", "opatch");
   my $tmpstr;

   $cmd = "$opatch version -oh $home";
   $rc = run_as_user2($ohown, \@output, $cmd);
   @cmdout = grep(/OPatch Version/, @output);
   $cmdout[0] =~ s/ //g;
   my ($txt , $ver) = split(/:/, $cmdout[0]);
   trace("opatch version in oracle home $home  is $ver");
   chomp $ver;

   return $ver;

}


sub checkOpatchver
{
   my $home = shift;
   my $ohown = getoracleowner($home);
   my $patchlist = shift;
   my $rc;
   my @cmdout;
   my @output;
   my $cmd;
   my $pdir;
   my $version;
   my $opatch = catfile ($home, "OPatch", "opatch");
   my $status = FAILED;
   $version = getOpatchver($home);   

   foreach $pdir (@$patchlist)
   {
      $cmd = "$opatch util checkMinimumOPatchVersion -ph $pdir -version $version -oh $home";
	  # report_cmd("$cmd");
      $rc = run_as_user2($ohown, \@output, $cmd);

      @cmdout = grep(/true/, @output);
      if ((scalar(@cmdout) > 0) && ($rc == 0)) {
         $status = SUCCESS;
      } else {
         error("The opatch minimum version  check for patch $pdir failed  for $home");
         trace("The opatch version check failed with following error");
         trace("@output");
      }
   }
   return $status;
}

sub checkOpatchverforhomes
{
   my @homelist = @_;
   my $chkver = SUCCESS;
   my $count;

   foreach my $home (@homelist) {
     my $status;
     trace("Processing oracle home $home");
     $homeType = findHomeType($home);
     trace("Home type of $home is $homeType");
     if ($homeType eq "CRS")
     {
        $status = checkOpatchver ($home, \@gipatches);
     }
     elsif ($homeType eq "HA")
     {
        $status = checkOpatchver ($home, \@hapatches);
     } 
     else {
        $status = checkOpatchver ($home, \@dbpatches);
     }

     trace("Status of opatch version check  for $home is $status");

     if ($status) {
         trace("Opatch version check passed for oracle home  $home");
     } else {
         error("Opatch version check failed for oracle home  $home");
         $count++;
     }
  }

  if ($count == 0) {
    trace ("Opatch version check passed  for all oracle homes");
  } else {
    error ("Opatch version  check failed");
    $chkver = FAILED;
  }

  return $chkver;
}

sub checkRollback
{
   my $pid = $_[0];
   my $home = $_[1];
   my $ohown = getoracleowner($home);
   my $rc;
   my @cmdout;
   my @output;
   my $cmd;
   my $opatch = catfile ($home, "OPatch", "opatch");
   my $status = FAILED;

   $cmd = "$opatch prereq checkRollbackable  -id $pid -oh $home";
   report_cmd("$cmd");
   $rc = run_as_user2($ohown, \@output, $cmd);

   @cmdout = grep(/passed/, @output);
   if ((scalar(@cmdout) > 0) && ($rc == 0)) {
         $status = SUCCESS;
   } else {
      error("The patch  $pid does not exist in $home");
      trace("The rollback check output is @output");
   }
   return $status;
}

sub unloadAIXfiles
{
  my $cmd = "/usr/sbin/slibclean";
  report_cmd("$cmd : run as root");
  if (! $report)
  {
	  my @out = system_cmd_capture("$cmd");
	  my $rc = shift @out;

	  trace("slibclean output is @out");
  }
}

sub getohlist
{
   my @ohlist;
   my @tmp_ohlist;
   my $path; 
 
   if ($ohome)
   {
      @tmp_ohlist = split( /\,/, $ohome);
      foreach $path (@tmp_ohlist) {
        $path =~ s/\/$//;
        push (@ohlist, $path);
      }
   } elsif ($chome) {
      @ohlist = $chome
   } else {
      @ohlist = findHomes();
   }

   return @ohlist;
}

sub getgridhome
{

   my $opdir = $_[0];
   my $cmd = "$opdir/../../srvm/admin/getcrshome";
   my $grhome;

   if (-e $cmd) {
      $grhome = `$cmd`;
   } else {
      exitOpatch("$cmd does not exist. unable to detect grid home");
   }

  return $grhome;

}

sub tolower_host
{
    my $host = hostname () or return "";

    # If the hostname is an IP address, let hostname remain as IP address
    # Else, strip off domain name in case /bin/hostname returns FQDN
    # hostname
    my $shorthost;
    if ($host =~ /^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$/) {
        $shorthost = $host;
    } else {
        ($shorthost,) = split (/\./, $host);
    }

    # convert to lower case
    $shorthost =~ tr/A-Z/a-z/;

    die "Failed to get non-FQDN host name for " if ($shorthost eq "");

    return $shorthost;
}

sub check_SuperUser
{
    my $superUser = "root";
    my $program   = "this script";

    # get user-name
    my $usrname = getpwuid ($<);
    if ($usrname ne $superUser) {
        error ("You must be logged in as $superUser to run $program.");
        error ("Log in as $superUser and rerun $program.");
        return "";
    }

    return $superUser;
}

sub setupINC {

  my @patches;
  my $incldir;
  my $patch;

  # Add the directory of this file to the search path
   my $crspatchincldir = $ENV{'CRSPATCH_INCL_PATH'};
   
   if ($crspatchincldir) {
      unshift @INC, $crspatchincldir;
   }

}

sub get_config_key
{
   my $src = $_[0];
   my $key = $_[1];
   $src    =~ tr/a-z/A-Z/;
   my ($val, $cfgfile);

   if ($src eq 'OCR') {
      $cfgfile = $ocrloc;
   }
   elsif ($src eq 'OLR') {
      $cfgfile = $olrloc;
   }

   open (CFGFL, "<$cfgfile") or return $val;
   while (<CFGFL>) {
      if (/^$key=(\S+)/) {
         $val = $1;
         last;
      }
   }
   close (CFGFL);
   return $val;
}
   
sub checkSIHA
{
   my $ret= FAILED;
   my $local_only = get_config_key("ocr", "local_only");
   if ($local_only =~ m/true/i) {
      $ret = SUCCESS;
   }
   return $ret;
}

sub emctlCmd
{
   my ($e_home, $e_option, $e_process) = @_;
   my $e_owner = getoracleowner($e_home);
   my $emctl = catfile($e_home, "bin", "emctl");

   if (-e $emctl)
   {
      my $cmd = "$emctl $e_option $e_process";
      my @output;
      report_cmd($cmd);
      if (! $report)
      {
         my $status = run_as_user2($e_owner, \@output, $cmd );
      }
   }
}

sub report_cmd
{
   print REPORTFILE "$step_count: $_[0]\n\n";
   $step_count++;
}

sub report_cfg
{
   print REPORTFILE "$_[0]\n";
}

sub generateCfg
{
   my $opatch_home = dirname ($scrdir);
   my $home = dirname ($opatch_home);
   my $ohown = getoracleowner($home);
   my $opatch = catfile($opatch_home, "opatch");
   my $opatchauto = catfile($scrdir, "opatchauto");
   
   my $rc;
   my @cmdout;
   my @output;
   my $status;
   
   my $cmd = "$opatchauto util saveconfigurationsnapshot -configFile $config_file";
   $rc = run_as_user2($ohown, \@output, $cmd);
      
   @cmdout = grep(/succeeded/, @output);
   if ((scalar(@cmdout) > 0) && ($rc == 0)) {
      $status = SUCCESS;
   } 
   else 
   {
      trace("Configuration needs to be generated without using saveconfigurationsnapshot");
      $status = FAILED;
   }
}

sub parseCfgFile
{
   open (CONFIGFILE, "< $config_file");
   my @cfgLines = <CONFIGFILE>;
   chomp @cfgLines;
   
   my $crs_version = "";
   my $db_home = "";
   my $opatch_version = "";
   
   # First capture CRS related data
   my $line = "";
   foreach $line (@cfgLines)
   {
      if( $line =~ /^\s*crs_home=(\S+)\s+version=(\S+)\s+/ )
      {
         $ORA_CRS_HOME = $1;
	 $crs_version = $2;
	 $opatch_version = getOpatchver($ORA_CRS_HOME);
	 if ($patchType =~ m/bundle_top/)
	 {
            report_cfg("$line      opatch_ver=$opatch_version");
         }
	 last;
      }
   }
   
   # Capture DB related data
   my @dbhomes_cfg = ();
   foreach $line (@cfgLines)
   {
      if( $line =~ /^\s*rac_home=(\S+)\s+version=(\S+)\s+/ )
      {
         if ( $crs_version eq $2 )
	 {
	    $db_home = $1;
	    push (@dbhomes_cfg, $db_home);
            $opatch_version = getOpatchver($db_home);
	    report_cfg("$line      opatch_ver=$opatch_version");
	 }
      }
   }
   
   @dbhomes = @dbhomes_cfg;
   close CONFIGFILE;
}

sub report_tgt_info
{
   my @targets = @_;
   my $home = "";
   my $home_type = "";
   
   foreach $home (@targets)
   {
      $home_type = findHomeType($home);
      my $opatch_version = getOpatchver($home);
      my $home_owner = getoracleowner($home);
      if ( ($home_type eq "CRS") || ($home_type eq "HA"))
      {
         if ($patchType =~ m/bundle_top/)
	 {
            report_cfg("crs_home=$home      owner=$home_owner      opatch_ver=$opatch_version");
         }
      }
      else
      {
          report_cfg("rac_home=$home      owner=$home_owner      opatch_ver=$opatch_version");
      }
   }
   
}

sub verifyPatchStorage
{
  my $create_flag = 1;
  my $ohown = getoracleowner("$ORA_CRS_HOME");
  my $userid   = getpwnam ($ohown);
  my $groupid;
  my $get_patchdir = "$ORA_CRS_HOME/OPatch";
  my ($name, $passwd, $uid, $gid, $quota, $comment, $gcos, $dir, $shell) = getpwuid( $< );
  if (  -e $get_patchdir)
  {
     my ($dev, $ino, $mode, $nlink, $uid, $gid, $rdev, $size, $atime, $mtime, $ctime, $blksize, $blocks) = stat( $get_patchdir );
     ($name, $passwd, $uid, $gid, $quota, $comment, $gcos, $dir, $shell) = getpwuid( $uid );
     $groupid = $gid;
  }
 
  if(! -d "$ORA_CRS_HOME/.patch_storage")
  {
    mkdir("$ORA_CRS_HOME/.patch_storage");
    chown($userid, $groupid, "$ORA_CRS_HOME/.patch_storage");
    chmod(oct("0750"), "$ORA_CRS_HOME/.patch_storage");
    unless(-d "$ORA_CRS_HOME/.patch_storage")
    {
       $create_flag = 0;
       trace("\nUnable to create patch storage directory\n");
    }
  }
  if($create_flag)
  {
     trace("\npatch storage directory verified successfully\n");
  }
}

sub exitOpatch
{
  my $error_message = $_[0];
  if($error_message)
  {
     error("ERROR: $error_message");
  }
  print "\nopatch auto failed.\n";
  exit 1;
}
 
##MAIN BODY

parseOptions();

if ($report)
{
   print "\nopatchauto is running in analyze/report mode. It will make no change to your system\n\n";
   trace("\nopatchauto is running in analyze/report mode. It will make no change to your system\n\n");
}

# Remove the trailing /
if ( $chome)
{
  $chome =~ s/\/$//;
}

$ORA_CRS_HOME = getcrshome();
$ORA_CRS_USER = getoracleowner($ORA_CRS_HOME);

makeCustomLogDir();
createPatchdir();
constructpatchlist();
trace("GI patches are @gipatches");
trace("SIHA patches are @hapatches");
trace("DB patches are @dbpatches");

open (REPORTFILE, "> $report_file");
generateCfg();

report_cfg("***********  Configuration Data  ***********");
report_cfg("* It shows only those targets that will be patched in this session *\n\n");

# If the cmd-line option '-och' is used
if ( $chome)
{
   my $homeType;
   $homeType = findHomeType($chome);
   if(($homeType ne "CRS") && ($homeType ne "HA"))
   {
      exitOpatch("Please provide GI Home location with -och option");
   }

   if ($patchType !~ m/bundle_top/)
   {
      exitOpatch("This patch is not applicable to GI home.");
   }
   $ORA_CRS_HOME = $chome;
   my $opatch_version = getOpatchver($ORA_CRS_HOME);
   my @crs_ver = getcrsversion();
   my $crs_version = join (".", @crs_ver);
   my $crs_owner = getoracleowner($ORA_CRS_HOME);
      
   @dbhomes = getohlist();
    
   report_cfg("crs_home=$chome      version=$crs_version      owner=$crs_owner      opatch_ver=$opatch_version");
}
# If the cmd-line option '-oh' is used
elsif ( $ohome)
{
   @dbhomes = getohlist();
   report_tgt_info(@dbhomes);   
}
# This is the most common case
elsif ( -f $config_file)
{
   parseCfgFile();
}
# Use old logic if config_file fails to get generated.
else
{
   @dbhomes = getohlist();   
   report_tgt_info($ORA_CRS_HOME, @dbhomes);
}

$ORA_CRS_USER = getoracleowner($ORA_CRS_HOME);

if($report)
{
  verifyPatchStorage();
}

report_cfg("\n*********** Steps to be executed as owner unless specified as root ***********\n\n");

$op_silent = checkOCM();
trace("silent mode option is $op_silent");

#check if clusterware running
$crs_running = isClusterwareup();

if ((! $crs_running) && (! $chome)) {
   print "Clusterware is either  not running or not configured. You have the following 2 options\n";
   print "1. Configure and Start the Clusterware on this node and re-run the tool\n";
   print "2. or Run the tool with the -och <CRS_HOME_PATH> option and then invoke  tool with -oh <comma seperated ORACLE_HOME_LIST> to patch the RDBMS home\n"; 
   exitOpatch("");
} 

if((@dbpatches) || ($ohome) || ($chome))
{
  @homestopatch = @dbhomes;
  @homestostart = @dbhomes;
}

if (($patchType =~ m/bundle_top/) && (! $ohome) && (! $chome))
{
   if((isSIHA() && (@hapatches)) || (!isSIHA() && (@gipatches)))
   { 
      unshift (@homestostart, $ORA_CRS_HOME);
      push (@homestopatch , $ORA_CRS_HOME);
   }
}  

if (! checkOpatchverforhomes(@homestopatch)) {
exitOpatch("update the opatch version for the failed homes and retry");
}

if (! isSIHA()) {
   isHomesShared(@homestopatch);
}

$isconflictok = checkConflictforhomes(@homestopatch);


if ($isconflictok == SUCCESS) {
    foreach my $home (@homestopatch) {

	my $status;
        my $cons_output;

	trace("Processing oracle home $home");
	$homeType = findHomeType($home);
	trace("Home type of $home is $homeType");


	if ($homeType eq "CRS")
	{
           report_cmd("$home/crs/install/rootcrs.pl -unlock : run as root");
	   if ( ! $report)
	   {
              print "\nStopping CRS...\n";
              open RED_STD, '>',\$cons_output or die "Unable to redirect console output to log file.\nopatch auto failed.\n";
              select RED_STD;
	      unlockCRSHomeforpatch();
	      #wait for complete stack to shutdown.
              sleep(120);
              trace("Waiting for complete CRS stack to stop");
              trace("$cons_output");
              select STDOUT;
              close RED_STD;
              if($cons_output !~ m/Successfully unlock/ )
              {
                 print "The Oracle Grid Infrastructure stack failed to stop.\n";
                 print "Resetting the status, starting CRS...\n";
                 $cons_output = "";
                 open RED_STD, '>',\$cons_output or die "Unable to redirect console output to log file.\nopatch auto failed.\n";
                 select RED_STD;
                 Instantiatepatchfiles ();
                 StartCRS();
                 trace("$cons_output");
                 select STDOUT;
                 close RED_STD;
                 exitOpatch("Failed to stop CRS.Refer log file for more details.\n");
              }   
              print "Stopped CRS successfully\n\n";
	   }
           removeproc($home, "crsctl.bin");
           $status = checkApplicable ($home, \@gipatches);
           if (! $report) { trace("Status of Applicable  check  for $home is $status"); }

           if (($prereq_status == SUCCESS) || ($rollback))
           {
             if ( $rollback ) {
               rollbackPatch($home, \@gipatchIds);
             }  else {
                  applyPatch($home, \@gipatches);
             }
           } else {
               error("Error:Patch Applicable check failed for $home");
               if (! $report)
               {
                 print "\nStarting CRS...\n";
                 $cons_output = "";
                 open RED_STD, '>',\$cons_output or die "Unable to redirect console output to log file.\nopatch auto failed.\n";
                 select RED_STD;
                 Instantiatepatchfiles ();
                 StartCRS();
                 trace("$cons_output");
                 select STDOUT;
                 close RED_STD;
                 exitOpatch("Prereq checkApplicable failed. Refer log file for more details.\n");
               }           
           }
       }
       elsif ($homeType eq "HA")
       {
           report_cmd("$home/crs/install/roothas.pl -unlock : run as root");
	   if ( ! $report)
	   {
              print "\nStopping CRS...\n";
              $cons_output = "";
              open RED_STD, '>',\$cons_output or die "Unable to redirect console output to log file.\nopatch auto failed.\n";
              select RED_STD;
	      unlockHAHomeforpatch();
              select STDOUT;
              close RED_STD;
              trace("$cons_output");
              if($cons_output !~ m/Successfully unlock/ )
              {
                 print "The Oracle Clusterware stack failed to stop.\n";
                 print "Resetting the status, starting CRS...\n";
                 $cons_output = "";
                 open RED_STD, '>',\$cons_output or die "Unable to redirect console output to log file.\nopatch auto failed.\n";
                 select RED_STD;
                 Instantiatepatchfiles ();
                 StartCRS();
                 trace("$cons_output");
                 select STDOUT;
                 close RED_STD;
                 exitOpatch("Failed to stop CRS.Refer log file for more details.\n");
              }
              print "Stopped CRS successfully\n\n";
	   }
           removeproc($home, "crsctl.bin");
           $status = checkApplicable ($home, \@hapatches);
           if (! $report) { trace("Status of Applicable  check  for $home is $status"); }
           if (($prereq_status == SUCCESS) || ($rollback))
           {
               if ( $rollback ) {
                   rollbackPatch($home, \@hapatchIds);
               }  else {
                     applyPatch($home, \@hapatches);
               }
           } else {
               error("Error:Patch Applicable check failed for $home");
	       if (! $report)
	       {
                 print "\nStarting CRS...\n";
                 $cons_output = "";
                 open RED_STD, '>',\$cons_output or die "Unable to redirect console output to log file.\nopatch auto failed.\n";
                 select RED_STD;
                 Instantiatepatchfiles ();
                 StartHA();
                 trace("$cons_output");
                 select STDOUT;
                 close RED_STD;
                 exitOpatch("Prereq checkApplicable failed. Refer log file for more details.\n");
	       }
           }
       } 
       else
       {
          emctlCmd($home, "stop", "dbconsole");
          trace("Performing DB patch");
          emctlCmd($home, "stop", "agent");
          $status = checkApplicable ($home, \@dbpatches);

          trace("Status of Applicable  check  for $home is $status");
          if (($prereq_status == SUCCESS) || ($rollback))
          {
             PerformDBPatch($home, \@dbpatches); 
          }  else {
               error("Error:Patch Applicable check failed for $home");
               if (! $report) {  
               exitOpatch(""); }
          }
       } 
    }
} else {
    exitOpatch("Conflict-Check has failed . Please refer to $logfile for details");
}

foreach my $home (@homestostart) {

#post patch sequence
   
   trace("Performing Post patch actions");
   trace("norestart flag is set to $norestart");
   $homeType = findHomeType($home);
   my $ohown = getoracleowner($home);
   my $issiha = isSIHA(); 

   if (! $norestart)
   {
      emctlCmd($home, "start", "dbconsole");
   }

#A hash of the norestart flag and its value to be passed below
   my %norestart_hash=("norestart",$norestart);
   my $rootcrs_patch;
   if ($homeType eq "CRS")
   {
          trace("Performing Post patch actions for Grid Home $home");
          setrdbmsfileperms($home);
          $rootcrs_patch = "$home/crs/install/rootcrs.pl -patch : run as root";
          if($norestart)
          {
              $rootcrs_patch = $rootcrs_patch . " (this command will start the stack)";
          }
          report_cmd($rootcrs_patch);
	  if (! $report)
	  {
             print "\nStarting CRS...\n";
             my $tmpOH = $ENV{ORACLE_HOME};
             $ENV{ORACLE_HOME} = $home;
             CRSPatch(\%norestart_hash);
             $ENV{ORACLE_HOME} = $tmpOH;
	  }
    } elsif ($homeType eq "HA") 
    {
          trace("Performing Post patch actions for HA Home $home");
          setrdbmsfileperms($home);
          $rootcrs_patch = "$home/crs/install/roothas.pl -patch : run as root";
          if($norestart)
          {
              $rootcrs_patch = $rootcrs_patch . " (this command will start the stack)";
          }
          report_cmd($rootcrs_patch);
	  if (! $report)
	  {
             print "\nStarting CRS...\n";
             my $tmpOH = $ENV{ORACLE_HOME};
             $ENV{ORACLE_HOME} = $home;
       	     HAPatch(\%norestart_hash);
             $ENV{ORACLE_HOME} = $tmpOH;
	  }
    } else {
          trace("Performing Post Patch start  action for DB Home $home");
          if  (! $norestart &&  isServerready() ) {
              emctlCmd($home, "start", "agent");
	      if ($issiha)
	      {  
		 report_cmd("$home/bin/srvctl start home -o $home -s $home/srvm/admin/stophome.txt"); 
	      }
	      else
	      {
		 report_cmd("$home/bin/srvctl start home -o $home -s $home/srvm/admin/stophome.txt -n $HOST"); 
	      }
	      if (! $report)
	      {
                 print "\nStarting RAC $home ...\n";
	         if(Startdbhomeres($home, $issiha,$ohown))
                 {
                    print "Started RAC $home successfully\n";
                 }
                 else
                 {
                    exitOpatch("Refer log file for more details.\n");
                 }
	      }
           }
   }
}

print "\nopatch auto succeeded.\n";     
0;
