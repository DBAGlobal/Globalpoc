#!/usr/local/bin/perl
# 
# $Header: opatch/crs_files/patchDB.pl /main/1 2015/06/01 02:50:44 srukumar Exp $
#
# patchDB.pl
# 
# Copyright (c) 2015, Oracle and/or its affiliates. All rights reserved.
#
#    NAME
#      patchDB.pl - <one-line expansion of the name>
#
#    DESCRIPTION
#      <short description of component this file declares/defines>
#
#    NOTES
#      <other useful comments, qualifications, etc.>
#
#    MODIFIED   (MM/DD/YY)
#    srukumar    05/13/15 - To patch only DB homes
#    srukumar    05/13/15 - Creation
#
# Documentation: usage output,
#   execute this script with -oh option
#
#

################ Documentation ################

# The SYNOPSIS section is printed out as usage when incorrect parameters
# are passed

=head1 NAME

  patchDB.pl - Auto patching tool for patching RAC homes.

=head1 SYNOPSIS

  opatch auto <patch directory> -oh <database home location>
              [-rollback]
              [-ocmrf <ocm response file location>]
              [-norestart]
              [-report]

  Options:

   patch_directory

             Default is the current directory.
             This is the top level directory path where the patch is 
             unzipped. 
            
             Always unzip the gipsu/DB one-off in a empty directory
             where there are no other directory/files existing.
            
             If the directory under which the patch is unzipped is /tmp/patchdir 
             
             Example:
             opatch auto /tmp/patchdir



 -rollback  

             The patch will be rolled back, not applied
             This option requires patch_directory to be passed

             Example:
             opatch auto /tmp/patchdir -rollback

 -oh         Database home locations    

             comma_delimited_list_of_oralcehomes_to_patch
	     In order to patch a 11.2 Database under Grid home of 
             version 12.1 and above, run opatch auto from the DB home.

             Example:
             opatch auto /tmp/patchdir -oh <oracle_home1_path,oracle_home2_path>

 -ocmrf      OCM response file location

             Absolute path of the OCM response file. This is required for
             silent mode patching

 -norestart  
             The database home resources will not be started after patching.

 -report
             opatch would be run in a report mode where all the prereq checks
             would be performed without modifying the binaries. The patch would
             not be applied/rolled-back on the home.


=head1 DESCRIPTION


  This script automates the complete patching process for a RAC database home.


=cut

################ End Documentation ################

use strict;
use English;
use Cwd;
use Cwd 'abs_path';
use FileHandle;
use File::Basename;
use File::Spec::Functions;
use File::Copy;
use Sys::Hostname;
use Net::Ping;
use Getopt::Long;
use Pod::Usage;

#print "CommandLine Arguments: @ARGV \n";

use constant SUCCESS               =>  "1";
use constant FAILED                =>  "0";
use constant TRUE                  =>  "1";
use constant FALSE                 =>  "0";
use constant ERROR                 =>  "-1";

#Global variables
our $g_help = 0;
our $g_unlock = 0;
our $g_patch = 0;
our $ghome = 0;
our $patching_status = "pass";

my $scrdir = abs_path(dirname ($0));

my $timestamp = gentimeStamp();

my $deflogdir = dirname(dirname($scrdir)) . "/cfgtoollogs";
my $logfile;
my $report_file;
my $config_file;
my $customLogDir;
my $step_count = 1;


if (-e $deflogdir)
{
   $logfile     = catfile($deflogdir,  "opatchauto$timestamp.log");
   $report_file = catfile($deflogdir,  "opatchauto$timestamp.report.log");
   $config_file = catfile($deflogdir,  "opatchauto$timestamp.cfg.log");

   $customLogDir= $deflogdir . "/opatchauto/core";
}
else
{
   $logfile     = catfile ($scrdir, "log", "opatchauto$timestamp.log");
   $report_file = catfile ($scrdir, "log", "opatchauto$timestamp.report.log");
   $config_file = catfile ($scrdir, "log", "opatchauto$timestamp.cfg.log");

   $customLogDir= $scrdir . "/log";
}

print "\nThis is the main log file: $logfile\n";
print "\nThis file will show your detected configuration and all the steps that opatchauto attempted to do on your system:\n$report_file\n\n";

my $patchdir;
my $patchdbdir;
my $patchfile;
my $patchnum;
my $rollback;
my $ohome;
my $ocmrf;
my $report;
my $norestart;
my $pwd = $ENV{'PWD'}?$ENV{'PWD'}:getcwd();
my $ocmrf;
my $report;
my $norestart;
my $pwd = $ENV{'PWD'}?$ENV{'PWD'}:getcwd();
my $OS = `uname`;
chomp $OS;
my $patchType;
my $homeType;
my @dbhomes = ();
my @homestopatch = ();
my @homestostart = ();
my ($name, $passwd, $uid, $gid, $quota, $comment, $gcos, $dir, $shell) = getpwuid( $< );
my @dbpatches = ();
my @dbpatchIds = ();
my @patchIds = ();
my @patchLocs = ();
my $isconflictok;
my $op_silent;
my $cfg;
my $prereq_status = SUCCESS;

my $echo;
my $mkdir;
my $cat;
my $perlbin;
my $kill;
my $fuser;
my $olrloc;
my $ocrloc;
my $su;


if ( $OS eq "Linux")
{
$echo = "/bin/echo";
$mkdir = "/bin/mkdir";
$cat = "/bin/cat";
$perlbin = "/usr/bin/perl";
$kill = "/bin/kill";
$fuser = "/sbin/fuser";
$olrloc = "/etc/oracle/olr.loc";
$ocrloc = "/etc/oracle/ocr.loc";
$su = "/bin/su";
}
elsif ($OS eq "HP-UX")
{
$echo = "/usr/bin/echo";
$mkdir = "/usr/bin/mkdir";
$cat = "/usr/bin/cat";
$perlbin = "/usr/bin/perl";
$kill = "/usr/bin/kill";
$fuser = "/usr/sbin/fuser";
$olrloc = "/var/opt/oracle/olr.loc";
$ocrloc = "/var/opt/oracle/ocr.loc";
$su =  "/usr/bin/su";
}
elsif ($OS eq "AIX" )
{
$echo = "/usr/bin/echo";
$mkdir = "/usr/bin/mkdir";
$cat = "/usr/bin/cat";
$perlbin = "/usr/bin/perl";
$kill = "/usr/bin/kill";
$fuser = "/usr/sbin/fuser";
$olrloc = "/etc/oracle/olr.loc";
$ocrloc = "/etc/oracle/ocr.loc";
$su =  "/usr/bin/su";
}
elsif ( $OS eq "SunOS" )
{
$echo = "/usr/bin/echo";
$mkdir = "/usr/bin/mkdir";
$cat = "/usr/bin/cat";
$perlbin = "/usr/bin/perl";
$kill = "/usr/bin/kill";
$fuser = "/usr/sbin/fuser";
$olrloc = "/var/opt/oracle/olr.loc";
$ocrloc = "/var/opt/oracle/ocr.loc";
$su =  "/usr/bin/su";
}
else
{
  die "ERROR: $OS is an Unknown Operating System\n";
}

# the return code to give when the incorrect parameters are passed
my $usage_rc = 1;

GetOptions('patchdir=s'     => \$patchdir,
           'patchfile=s'    => \$patchfile,
           'patchnum=s'     => \$patchnum,
           'rollback'       => \$rollback,
           'oh=s'           => \$ohome,
           'ocmrf=s'        => \$ocmrf,
           'report'         => \$report,
           'norestart'      => \$norestart,
           'help!'          => \$g_help) or pod2usage($usage_rc);


# Check validity of args
pod2usage(-msg => "Invalid extra options passed: @ARGV",
          -exitval => $usage_rc) if (@ARGV);

### Set this host name (lower case and no domain name)
our $HOST = tolower_host();
die "$!" if ($HOST eq "");

@dbhomes = split(/\,/, $ohome); 

$patchdir = "$patchdir/$patchnum";

if (!$g_help && ! $patchdir)
{
   error("-patchdir is a  Mandatory option");
   pod2usage(1);
}

trace ("INC is @INC \n");


#Subroutines used by this tool


#Remove trailing white spaces in a string
sub trim($)
{
    my $string = shift;
    $string =~ s/^\s+//;
    $string =~ s/\s+$//;
    return $string;
}


sub makeCustomLogDir
{
   my $cmd;
   my $status;
   my @output;
   my $reference_dir;
   my $owner;

   #Create the CustomLogDir for opatch-core
   if( $customLogDir && ! -d $customLogDir )
   {
       if (-e $deflogdir)
       {
         $reference_dir = $deflogdir;
       }
       else
       {
          $reference_dir = $scrdir;
       }

       my $uid = (stat $reference_dir) [4];
       $owner  = (getpwuid $uid) [0];

       # Create 'opatch' inside customLogDir with perm 755 so that all owners can access
       my $opatch_log_dir = $customLogDir . "/opatch";
       $cmd = "$mkdir -m 777 -p $opatch_log_dir";
       trace( "Executing $cmd as $owner" );
       my ($output, $status) = execute_cmd( $owner, $cmd );
       trace( "Status: $status");

       # Create a dummy file so that opatch-core doesn't change dir permissions
       my $opatchauto_custom = $opatch_log_dir."/opatchauto.txt";
       open my $handle, '>', $opatchauto_custom;
       print $handle "opatchauto custom log location for opatch core logs";
       close $handle;
   }

   if ( ! -d $customLogDir )
   {
       trace( "Failed to create customLogDir :\n @output");
   }
   else
   {
     my $opatch_log_dir = $customLogDir . "/opatch";
     chmod 0777, $opatch_log_dir;
   }

}


sub execute_cmd
{
    my $oh_owner = $_[0];
    my $command = $_[1];
    #my $command = join ' ', @_;
    my $final_cmd;
    trace( "\nExecuting command as $oh_owner : $command " );

    if ($oh_owner eq "root" )
    {
      $final_cmd = $command;
    }
    else
    {
      $final_cmd = "$su $oh_owner";
      if ( ($OS ne "HP-UX") && ($OS ne "SunOS" ) )
      {
        $final_cmd = "$final_cmd -m";
      }	
      $final_cmd = "$final_cmd -c \"$command\" ";
    }


    trace( "Command run as owner: $final_cmd");
    #return (@output = qx{$final_cmd 2>&1}, $? >> 8);
    my $output = `$final_cmd 2>&1`;
    my $result = $? >> 8;
    return ($output , $result );

}


sub trace
{
    my ($sec, $min, $hour, $day, $month, $year) =
        (localtime) [0, 1, 2, 3, 4, 5];
    $month = $month + 1;
    $year = $year + 1900;

    open (TRCFILE, ">>$logfile")
          or die "trace(): Can't open $logfile for append: $!";
    
    printf TRCFILE  "\n%04d-%02d-%02d %02d:%02d:%02d: @_\n",
        $year, $month, $day, $hour, $min, $sec;
    close (TRCFILE);

}


sub tolower_host
{
    my $host = hostname () or return "";

    # If the hostname is an IP address, let hostname remain as IP address
    # Else, strip off domain name in case /bin/hostname returns FQDN
    # hostname
    my $shorthost;
    if ($host =~ /^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$/) {
        $shorthost = $host;
    } else {
        ($shorthost,) = split (/\./, $host);
    }

    # convert to lower case
    $shorthost =~ tr/A-Z/a-z/;

    die "Failed to get non-FQDN host name for " if ($shorthost eq "");

    return $shorthost;
}


sub gentimeStamp
{
  my ($sec, $min, $hour, $day, $month, $year) =
        (localtime) [0, 1, 2, 3, 4, 5];
  $month = $month + 1;
  $year = $year + 1900;

  my $ts = sprintf("%04d-%02d-%02d_%02d-%02d-%02d",$year, $month, $day, $hour, $min, $sec);
  return $ts;
}


sub findPatchType
{
  #Determine the type of patch
  my $pdir = $_[0];
  my $patchtype;
  my @cmdout;
  my @output;
  my @outp;
  my $rc;
  my $patchcount;
  my $opatch = catfile ($dbhomes[0], "OPatch", "opatch");
  my $cmd = "$opatch query -get_patch_type $pdir -oh $dbhomes[0]";
  my $owner = getoracleowner($dbhomes[0]);
  my ($cmdout, $rc) = execute_cmd( $owner, $cmd );
  my @cmdout_a = split(/\n/, $cmdout);
  @output = grep(/This patch/, @cmdout_a);
  trace("output is @output");
  @outp = split(" ", $output[0]);
  $patchtype = $outp[4];
  trace ("Patch type is $patchtype");
  return $patchtype;
}


sub getpatches
{
  my @patches = ();
  my $patchcount;
  my $patchids;
  my $usrinput;

  my $bfile = catfile($patchdir, "bundle.xml");
  if (-e $bfile) {
     @patches = getpids($patchdir);
  } else {
          print "Enter 'yes' if you have unzipped this patch to an empty directory to proceed  (yes/no):";
          $usrinput = <STDIN>;
          if ($usrinput =~ m/yes/i) {
            ($patchcount, $patchids) = getPatchids($patchdir);
            @patches = split(/\,/, $patchids);
          } else {
              exitOpatch("Unable to find patches");
          }
  }
  trace("The patch ids are @patches");
  return @patches
}


sub constructpatchlist
{
  my $patch;
  my $ptype;

  @patchIds = getpatches();
  @patchLocs = getpatchlocs($patchdir);

  my $patchtype = "DB";
  foreach $patch (@patchIds)
  {
     $ptype = findPatchType("$patchdir/$patch");
     if ($ptype =~ m/bundle_top/) {
        $patchtype = $ptype;
     }
  }
  $patchType = $patchtype;
}


sub checkApplicable
{
   my $home = shift;
   my $ohown = getoracleowner($home);
   my $patchlist = shift;
   my @cmdout;
   my $cmd;
   my $opatch = catfile ($home, "OPatch", "opatch");
   my $pdir;
   my $status = FAILED;


   #Check if the patch is applicable
   foreach $pdir (@$patchlist)
   {


      $cmd = "$opatch prereq CheckApplicable -ph $pdir -oh $home";
      report_cmd("$cmd");
      if (! $report)
      {
         my ($output, $rc) = execute_cmd( $ohown, $cmd );

	 my @output_a = split(/\n/, $output);
         @cmdout = grep(/passed/, @output_a);

         if ((scalar(@cmdout) > 0) && ($rc == 0)) {
            $status = SUCCESS;
         }
         else {
                error("Error : The opatch Applicable check failed.  The patch $pdir is not applicable to $home");
                $prereq_status = FAILED;
         }
      }
      else {
         $status = SUCCESS;
      }
   }
   return $status;
}


sub checkConflict
{
   my $home = shift;
   my $ohown = getoracleowner($home);
   my $patchlist = shift;
   my $rc;
   my @cmdout;
   my $output;
   my $cmd;
   my $opatch = catfile ($home, "OPatch", "opatch");
   my $pdir;
   my $status = SUCCESS;

   foreach $pdir (@$patchlist)
   {
      #Check if there are patch conflicts.
      $cmd = "$opatch prereq CheckConflictAgainstOH -ph $pdir -oh $home";
          report_cmd("$cmd");

      #$rc = run_as_user2($ohown, \@output, $cmd);
      ($output, $rc) = execute_cmd( $ohown, $cmd );

      my @output_a = split(/\n/, $output);
      @cmdout = grep(/ZOP-40/, @output_a);

      # if scalar(@cmdout) > 0, we found the msg we were looking for
      if ((scalar(@cmdout) > 0) && ($rc == 0)) {
         $status = FAILED;
         if (! $rollback) {
         error("The opatch Conflict check failed  for $home. The patch $pdir is either already applied or conflicting with another patch applied in the home");
         trace("The error ouput from opatch is $output");
         }
      }
   }
   return $status;
}


sub checkComponent
{
   my $home = shift;
   my $ohown = getoracleowner($home);
   my $patchlist = shift;
   my $rc;
   my @cmdout;
   my $output;
   my $cmd;
   my $opatch = catfile ($home, "OPatch", "opatch");
   my $pdir;
   my $status = SUCCESS;

   foreach $pdir (@$patchlist)
   {
      #Check if the patch is applicable
      $cmd = "$opatch prereq CheckComponents -ph $pdir -oh $home";
          report_cmd("$cmd");

      #$rc = run_as_user2($ohown, \@output, $cmd);
      ($output, $rc) = execute_cmd( $ohown, $cmd );

      my @output_a = split(/\n/, $output);
      @cmdout = grep(/passed/, @output_a);

      if (!(scalar(@cmdout) >  0) || ( 0 != $rc )) {
         $status = FAILED;
         error("The opatch Component check failed. This patch is not applicable for $home");
         trace("The component check failed with following error");
         trace("$output");
      }
   }
   return $status;
}


sub applyPatch
{
   my $home = shift;
   my $ohown = getoracleowner($home);
   my $patchlist = shift;
   my $cmd = ""; 
   my $status;
   my $opatch = catfile ($home, "OPatch", "opatch");
   my $pdir;
   my $output = ();
   if  ($OS eq "AIX" ) {
         unloadAIXfiles();
       }
   foreach $pdir (@$patchlist)
   {
      $cmd = "$opatch napply $pdir -local $op_silent -oh $home -invPtrLoc $home/oraInst.loc";
          report_cmd("$cmd");
          if ($report)
          {
             $cmd = "$cmd -report";
          }
          trace("Executing command $cmd");
      #$status = run_as_user2($ohown, \@output, $cmd );
      ($output, $status) = execute_cmd( $ohown, $cmd );
      trace("status of apply patch " . ($report?"(report mode) ":"") . "is $status");
      trace("The apply patch " . ($report?"(report mode) ":"") . "output is $output");
      if (0 != $status) {
        error("patch $pdir  apply " . ($report?"(report mode) ":"") . "failed  for home  $home");
	$patching_status = "fail";
        last;
      } else {
        trace("patch $pdir  apply " . ($report?"(report mode) ":"") . "successful for home  $home");
        print "patch $pdir  apply " . ($report?"(report mode) ":"") . "successful for home  $home \n";
      }

   }

}


sub rollbackPatch
{
   my $home = shift;
   my $ohown = getoracleowner($home);
   my $patchlist = shift;
   my $status = 0;
   my $output = ();
   my $opatch = catfile ($home, "OPatch", "opatch");
   my $pnum;
   my $skip;

   if  ($OS eq "AIX" ) {
         unloadAIXfiles();
       }
   foreach $pnum (@$patchlist)
   {
      $skip = FALSE;
      trace("checking if patch $pnum exists in $home");
      if (checkRollback($pnum, $home))
      {
         my $cmd = "$opatch rollback -id $pnum -local -silent -oh $home -invPtrLoc $home/oraInst.loc";
         report_cmd("$cmd");
         if ($report)
         {
            $cmd = "$cmd -report";
         }
         trace("Executing command $cmd");
         #$status = run_as_user2($ohown, \@output, $cmd );
         ($output, $status) = execute_cmd( $ohown, $cmd );
         trace("status of rollback patch " . ($report?"(report mode) ":"") . "is $status");
         trace("The rollback patch " . ($report?"(report mode) ":"") . "output is $output");
      } else {
         trace("Rollback of $pnum failed. Patch may not have been applied, skipping rollback.");
         $skip = TRUE;
      }
      if (0 != $status) {
        error("patch $pnum  rollback " . ($report?"(report mode) ":"") . "failed for home  $home");
	$patching_status = "fail";
        last;
      } else {
          if (! $skip) {
             trace("patch $pnum  rollback " . ($report?"(report mode) ":"") . "successful for home $home");
             print "patch $pnum  rollback " . ($report?"(report mode) ":"") . "successful for home $home\n";
         }
      }

   }
}


sub removeproc
{
  my $home = $_[0];
  my $proc = $_[1];
  my $cmd ;
  my $out;
  my $rc;

  my $fpath = catfile($home, "bin", $proc);
  $cmd = "$fuser -k $fpath";
  report_cmd("$cmd");

  if (! $report)
  {
          trace("Invoking removeproc to clean oracle client procs");
          #@out = system_cmd_capture("$cmd");
          ($out, $rc) = execute_cmd( "root", $cmd );

          if (0 == $rc) {
                 trace("fuser command success. output for $fpath is $out");
          } else {
                 trace("fuser command output for $fpath is $out");
          }
  }
}


sub PerformDBPatch
{ 
  my $home = shift;
  my $patchlist = shift;
  my $ohown = getoracleowner($home);
  my $cmd;
  my $status;
  my $output;
  my $pdir;
  
  #my @crs_version = getcrsversion();


  my $issiha = isSIHA();
  if ($issiha)
  {
     $cmd = "$home/bin/srvctl stop home -o $home -s $home/srvm/admin/stophome.txt";
  }
  else
  {
     $cmd = "$home/bin/srvctl stop home -o $home -s $home/srvm/admin/stophome.txt -n $HOST";
  }
  report_cmd("$cmd");

  if ( ! $report)
  {
          $ENV{ORACLE_HOME} = $home;
          my $stfile = catfile ($home, "srvm", "admin", "stophome.txt");
          if (-e $stfile) {
	    unlink $stfile;
          }
          print "\nStopping RAC $home ...\n";
          ($output, $status) = execute_cmd( $ohown, $cmd );
          trace("$cmd output is $output");


          if ($status == 0)
          {
                 print "Stopped RAC $home successfully\n\n";
          }
          else
          {
              exitOpatch("Refer log file for more details.\n");
          }
  }
  foreach $pdir (@$patchlist)
  {
     if (-e "$pdir/custom/scripts/prepatch.sh") {
        $cmd = "$pdir/custom/scripts/prepatch.sh -dbhome $home";
                report_cmd("$cmd");
     } else {
        $cmd = "true";
     }

     if ( ! $report)
     {
        ($output, $status) = execute_cmd( $ohown, $cmd );
        trace("$cmd output is $output");
     }
  }
  if ($report || $status == 0) {
     if (! $report) { trace ("prepatch execution for DB home ... success"); }
     if ( $rollback ) {
       rollbackPatch($home, \@dbpatchIds);
     } else {
       applyPatch($home, \@$patchlist);
     }
   } else {
      exitOpatch("prepatch execution for DB home ... failed");
   }

  foreach $pdir (@$patchlist)
  {
     if (-e "$pdir/custom/scripts/postpatch.sh") {
        $cmd = "$pdir/custom/scripts/postpatch.sh -dbhome $home";
                report_cmd("$cmd");
     } else {
        $cmd = "true";
     }

     if ( ! $report)
     {
        ($output, $status) = execute_cmd( $ohown, $cmd );
        trace("$cmd output is $output");
     }
  }

  if ( $status == 0) {
      trace ("postpatch execution for DB home ... success");
   } elsif ( ! $report) {
      exitOpatch("postpatch execution for DB home ... failed");
  }
}


sub getPatchids
{
 my $searchdir = $_[0];
 my $ids;
 my $line;
 my $idx;

 my @dbids = <$searchdir/*>;
 foreach $line (@dbids)
 {
  chomp($line);
  if ( -d $line) {
   $idx++;
   my @temp = split(/\//, $line);
   $ids = $ids . $temp[-1] . ",";
  }
 }
 chop $ids;
 return ($idx, $ids);
}


sub read_file
{
    my $file = $_[0];
    open (FILE, "<$file") or die "Can't open $file: $!";
    my @contents = (<FILE>);
    close (FILE);

    return @contents;
}


sub getpids
{
 my $searchdir = $_[0];
 my $bfile = catfile($searchdir, "bundle.xml");
 my @list;
 my @out;
 my $ids;
 my $tag;
 my @pids;

 @list = read_file( $bfile);

 @out = grep(/entity location/, @list);
 foreach my $rec (@out) {
   chomp($rec);
   if ($rec =~ m/custom/) {
      next;
   } else {
      $rec =~ s/<|>|"//g;
      ($tag, $ids) = split(/=/,$rec);
      push @pids, $ids;
   }
 }
 #trace("The patch ids are @pids");
 return @pids;
}


sub getpatchlocs
{
 my $searchdir = $_[0];
 my $bfile = catfile($searchdir, "bundle.xml");
 my @locs = ();
 my @bfileData;
 my $tag;
 my $type;
 my @pidlist = ();
 my $ploc;
 my $pid;
 my $validtag = 0;

 if(-e $bfile)
 {
 @bfileData = read_file($bfile);
 foreach my $entity (@bfileData)
 {
  if($entity =~ m/<\/entity>/)
  {
    $validtag = 0;
    next;
  }
  if($entity =~ m/entity location/)
  {
   $validtag = 1;
   $entity =~ s/<|>|"//g;
   ($tag, $ploc) = split(/=/,$entity);
   chomp($ploc);
   push @locs, "$patchdir/$ploc";
   if($ploc =~ m/custom\/server/)
   {
    ($tag,$pid) = split(/server\//,$ploc);
    chomp($pid);
   }
   else
   {
    $pid = $ploc;
   }
  }
  if($entity =~ m/target type/)
  {
    $entity =~ s/<|>|"//g;
    ($tag, $type) = split(/=/,$entity);
    chomp($type);
    if(($type =~ m/rac/) && ($validtag == 1))
    {
      push @dbpatches, "$patchdir/$ploc";
      push @dbpatchIds, $pid;
    }
    else
    {
      next;
    }
   }
  }
 }
 else
 {
   @pidlist = getpatches();
   foreach my $id (@pidlist)
   {
     push @locs, "$patchdir/$id";
     #push @gipatches, "$patchdir/$id";
     #push @hapatches, "$patchdir/$id";
     push @dbpatches, "$patchdir/$id";
     #push @gipatchIds, $id;
     #push @hapatchIds, $id;
     push @dbpatchIds, $id;
   }
 }
 #trace("The GI patch locations are @gipatches");
 #trace("The GI patch IDs are @gipatchIds");
 #trace("The SIHA patch locations are @hapatches");
 #trace("The SIHA patch IDs are @hapatchIds");
 trace("The DB patch locations are @dbpatches");
 trace("The DB patch IDs are @dbpatchIds");
 return @locs;
}


sub error
{
  print "ERROR: @_\n";
  trace(@_);
}


sub checkConflictforhomes
{
   my @homelist = @_;
   my $chkconflict = SUCCESS;
   my $count;

   foreach my $home (@homelist) {
     my $status;
     trace("Processing oracle home $home");
        if ( $rollback) {
             $status = checkComponent ($home, \@dbpatches);
        } else {
             $status = (checkComponent ($home, \@dbpatches) &&  checkConflict ($home, \@dbpatches));
        }

     trace("Status of component/conflict check  for $home is $status");

     if ($status) {
         trace(" Conflict check passes for oracle home  $home");
     } else {
         error("Conflict check failed for oracle home  $home");
         $count++;
     }
  }


  if ($count == 0) {
    trace ("Conflict check passed  for all oracle homes");
  } else {
    error ("Conflict check failed");
    $chkconflict = FAILED;
  }

  return $chkconflict;
}


sub checkOCM
{
  my $ORA_HOME = shift;
  my $silentflg;
  my $ocmrspfile;

  #check if opatch is bundled with OCM
  if ( -e "$ORA_HOME/OPatch/ocm/bin/emocmrsp")
  {
    if ($ocmrf)
    {
      $ocmrspfile = $ocmrf;
    }
    else {
       error("OPatch  is bundled with OCM, Enter the absolute OCM response file path:") ;
       $ocmrspfile = <STDIN>;
       chomp $ocmrspfile;
       $ocmrspfile =~ s/^\s+//;
       $ocmrspfile =~ s/\s+$//;
    }
    if ( -e $ocmrspfile)
    {
      $silentflg = "-silent -ocmrf $ocmrspfile";
    }
    else
    {
      exitOpatch("Invalid response file path, To regenerate an OCM response file run $ORA_HOME/OPatch/ocm/bin/emocmrsp");
    }
  }
  else
  {
    #report( 0, 0, "$opatch is not bundled with OCM" );
    $silentflg = "-silent";
  }

  return $silentflg;

}


sub getOpatchver
{
   my $home = shift;
   my $ohown = getoracleowner($home);
   my $rc;
   my @cmdout;
   my $output;
   my $cmd;
   my $opatch = catfile ($home, "OPatch", "opatch");
   my $tmpstr;

   $cmd = "$opatch version -oh $home";
   ($output, $rc) = execute_cmd( $ohown, $cmd );
   my @output_a = split(/\n/, $output);
   @cmdout = grep(/OPatch Version/, @output_a);
   $cmdout[0] =~ s/ //g;
   my ($txt , $ver) = split(/:/, $cmdout[0]);
   trace("opatch version in oracle home $home  is $ver");
   chomp $ver;

   return $ver;

}


sub checkOpatchver
{
   my $home = shift;
   my $ohown = getoracleowner($home);
   my $patchlist = shift;
   my $rc;
   my @cmdout;
   my $output;
   my $cmd;
   my $pdir;
   my $version;
   my $opatch = catfile ($home, "OPatch", "opatch");
   my $status = FAILED;
   $version = getOpatchver($home);

   foreach $pdir (@$patchlist)
   {
      $cmd = "$opatch util checkMinimumOPatchVersion -ph $pdir -version $version -oh $home";
          # report_cmd("$cmd");
      ($output, $rc) = execute_cmd( $ohown, $cmd );

      my @output_a = split(/\n/, $output);
      @cmdout = grep(/true/, @output_a);
      if ((scalar(@cmdout) > 0) && ($rc == 0)) {
         $status = SUCCESS;
      } else {
         error("The opatch minimum version  check for patch $pdir failed  for $home");
         trace("The opatch version check failed with following error");
         trace("$output");
      }
   }
   return $status;
}


sub checkOpatchverforhomes
{  
   my @homelist = @_;
   my $chkver = SUCCESS;
   my $count;
   
   foreach my $home (@homelist) {
     my $status;
     trace("Processing oracle home $home");
        $status = checkOpatchver ($home, \@dbpatches);

     trace("Status of opatch version check  for $home is $status");

     if ($status) {
         trace("Opatch version check passed for oracle home  $home");
     } else {
         error("Opatch version check failed for oracle home  $home");
         $count++;
     }
  }

  if ($count == 0) {
    trace ("Opatch version check passed  for all oracle homes");
  } else {
    error ("Opatch version  check failed");
    $chkver = FAILED;
  }

  return $chkver;
}


sub checkRollback
{
   my $pid = $_[0];
   my $home = $_[1];
   my $ohown = getoracleowner($home);
   my $rc;
   my @cmdout;
   my $output;
   my $cmd;
   my $opatch = catfile ($home, "OPatch", "opatch");
   my $status = FAILED;

   $cmd = "$opatch prereq checkRollbackable  -id $pid -oh $home";
   report_cmd("$cmd");
   ($output, $rc) = execute_cmd( $ohown, $cmd );

   my @output_a = split(/\n/, $output);
   @cmdout = grep(/passed/, @output_a);
   if ((scalar(@cmdout) > 0) && ($rc == 0)) {
         $status = SUCCESS;
   } else {
      error("The patch  $pid does not exist in $home");
      trace("The rollback check output is $output");
   }
   return $status;
}


sub unloadAIXfiles
{
  my $cmd = "/usr/sbin/slibclean";
  report_cmd("$cmd : run as root");
  if (! $report)
  {
     my ($out, $rc) = execute_cmd( "root", $cmd );

     trace("slibclean output is $out");
  }
}


sub getohlist
{
   my @ohlist;
   my @tmp_ohlist;
   my $path;

   if ($ohome)
   {
      @tmp_ohlist = split( /\,/, $ohome);
      foreach $path (@tmp_ohlist) {
        $path =~ s/\/$//;
        push (@ohlist, $path);
      }
   } else {
      exitOpatch("Use '-oh' parameter in order to patch a 11.2 Database with a 12.1 or higher version GI");
   }

   return @ohlist;
}


sub getgridhome
{

   my $opdir = $_[0];
   my $cmd = "$opdir/../../srvm/admin/getcrshome";
   my $grhome;

   if (-e $cmd) {
      $grhome = `$cmd`;
   } else {
      exitOpatch("$cmd does not exist. unable to detect grid home");
   }

  return $grhome;

}


sub get_config_key
{
   my $src = $_[0];
   my $key = $_[1];
   $src    =~ tr/a-z/A-Z/;
   my ($val, $cfgfile);

   if ($src eq 'OCR') {
      $cfgfile = $ocrloc;
   }
   elsif ($src eq 'OLR') {
      $cfgfile = $olrloc;
   }

   open (CFGFL, "<$cfgfile") or return $val;
   while (<CFGFL>) {
      if (/^$key=(\S+)/) {
         $val = $1;
         last;
      }
   }
   close (CFGFL);
   return $val;
}


sub isSIHA
{
   my $ret= FAILED;
   my $local_only = get_config_key("ocr", "local_only");
   if ($local_only =~ m/true/i) {
      $ret = SUCCESS;
   }
   return $ret;
}


sub emctlCmd
{
   my ($e_home, $e_option, $e_process) = @_;
   my $e_owner = getoracleowner($e_home);
   my $emctl = catfile($e_home, "bin", "emctl");

   if (-e $emctl)
   {
      my $cmd = "$emctl $e_option $e_process";
      my $output;
      my $status;
      report_cmd($cmd);
      if (! $report)
      {
         ($output, $status) = execute_cmd( $e_owner, $cmd );      
      }
   }
}


sub report_cmd
{
   print REPORTFILE "$step_count: $_[0]\n\n";
   $step_count++;
}

sub report_cfg
{
   print REPORTFILE "$_[0]\n";
}


sub report_tgt_info
{
   my @targets = @_;
   my $home = "";

   foreach $home (@targets)
   {
      my $opatch_version = getOpatchver($home);
      my $home_owner = getoracleowner($home);
      report_cfg("rac_home=$home      owner=$home_owner      opatch_ver=$opatch_version");
   }

}


sub getoracleowner
{
  my $oh = $_[0];
  my $getoh_ox = "$oh/bin/oracle";
  my $getoh_u;
  if (  -f $getoh_ox )
  {
     my ($dev, $ino, $mode, $nlink, $uid, $gid, $rdev, $size, $atime, $mtime, $ctime, $blksize, $blocks) = stat( $getoh_ox );
     ($name, $passwd, $uid, $gid, $quota, $comment, $gcos, $dir, $shell) = getpwuid( $uid );
     $getoh_u = $name;
     trace( "Oracle user for $oh is $getoh_u" );
  }
  else {
     exitOpatch("Unable to get oracle owner for $oh");
  }
  return $getoh_u;
}


sub exitOpatch
{
  my $error_message = $_[0];
  if($error_message)
  {
     error("ERROR: $error_message");
  }
  print "\nopatch auto failed.\n";
  exit 1;
}

sub check_SuperUser
{
    # get user-name
    my $usrname = getpwuid ($<);
    if ($usrname ne "root") {
      exitOpatch ("You must be logged in as root to run this script. Log in as root and rerun the script.");

    }
    
}

sub parseOptions
{
   if    ($g_help)   { pod2usage(0); }

   if ( ! $patchdir )
   {
      $patchdir = $pwd;
      trace("using current directory $patchdir for patch directory");
   }

   if( ! $patchfile )
   {
      trace("No -patchfile specified, assuming the patch is already uncompressed" );
   }

}


sub Startdbhomeres
{
   my $home = $_[0];
   my $sihadb = $_[1];
   #my $ohown = $_[2];
   my $ohown = getoracleowner($home);

   my $srvctlbin    = catfile ($home, "bin", "srvctl");
   my $nodename = $HOST;
   my $success = SUCCESS;
   my $cmd;
   my $output;
   my $status;

   my $stfile = catfile ($home, "srvm", "admin", "stophome.txt");

   if ( ! $sihadb ) {
      $cmd = "$srvctlbin start home -o $home -s $stfile -n $nodename";
   } else {
       $cmd = "$srvctlbin start home -o $home -s $stfile";
   }

   $ENV{ORACLE_HOME} = $home;
   ($output, $status) = execute_cmd( $ohown, $cmd );

   trace("$cmd output is $output");

   if ($status != 0) {
     error("Failed to start resources from  database home $home");
     $success = FAILED;
   } else {
     trace("Started resources from datbase home $home");
  }

  unlink ($stfile);
  return $success;
}


############ Main Body execution ##############

check_SuperUser();

parseOptions();

if ($report)
{
   print "\nopatchauto is running in analyze/report mode. It will make no change to your system\n\n";
   trace("\nopatchauto is running in analyze/report mode. It will make no change to your system\n\n");
}


makeCustomLogDir();
constructpatchlist();

trace("DB patches are @dbpatches");

open (REPORTFILE, "> $report_file");


report_cfg("***********  Configuration Data  ***********");
report_cfg("* It shows only those targets that will be patched in this session *\n\n");


if ( $ohome)
{
   @dbhomes = getohlist();
   report_tgt_info(@dbhomes);
}
else
{
    exitOpatch("Please provide -oh option in order to patch databases running on a higher version GI");
}

report_cfg("\n*********** Steps to be executed as owner ***********\n\n");

$op_silent = checkOCM($dbhomes[0]);
trace("silent mode option is $op_silent");

@homestopatch = @dbhomes;
@homestostart = @dbhomes;


if (! checkOpatchverforhomes(@homestopatch)) {
exitOpatch("update the opatch version for the failed homes and retry");
}

#isHomesShared(@homestopatch);

$isconflictok = checkConflictforhomes(@homestopatch);

if ($isconflictok == SUCCESS) {
    foreach my $home (@homestopatch) {

        my $status;
        my $cons_output;

        trace("Processing oracle home $home");
          emctlCmd($home, "stop", "dbconsole");
          trace("Performing DB patch");
          emctlCmd($home, "stop", "agent");
          $status = checkApplicable ($home, \@dbpatches);

          trace("Status of Applicable  check  for $home is $status");
          if (($prereq_status == SUCCESS) || ($rollback))
          {
             PerformDBPatch($home, \@dbpatches);
          }  else {
               error("Error:Patch Applicable check failed for $home");
               if (! $report) {
               exitOpatch(""); }
          }
    }
} else {
    exitOpatch("Conflict-Check has failed . Please refer to $logfile for details");
}


foreach my $home (@homestostart) {

#post patch sequence

   trace("Performing Post patch actions");
   trace("norestart flag is set to $norestart");
   my $issiha = isSIHA();

   if (! $norestart)
   {
      emctlCmd($home, "start", "dbconsole");
   }

   trace("Performing Post Patch start  action for DB Home $home");
   if  (! $norestart ) {
              emctlCmd($home, "start", "agent");
              if ($issiha)
              {  
                 report_cmd("$home/bin/srvctl start home -o $home -s $home/srvm/admin/stophome.txt");
              }
              else
              {
                 report_cmd("$home/bin/srvctl start home -o $home -s $home/srvm/admin/stophome.txt -n $HOST"); 
              }
              if (! $report)
              {
                 print "\nStarting RAC $home ...\n";
                 if(Startdbhomeres($home, $issiha))
                 {
                    print "Started RAC $home successfully\n";
                 }
                 else
                 {
                    exitOpatch("Refer log file for more details.\n");
                 }
              }
           }
}

if ($patching_status eq "fail")
{
  print "\nopatch auto failed to " . ($rollback?"rollback ":"apply ") . "some patches.\n";
  exit 1;
}

print "\nopatch auto succeeded.\n";     
0;


